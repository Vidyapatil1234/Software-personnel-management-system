function generateReport() {
    alert("Report Generated!");
}
